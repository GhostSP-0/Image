/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_KEXEC_BZIMAGE64_H
#define _ASM_KEXEC_BZIMAGE64_H

extern const struct kexec_file_ops kexec_bzImage64_ops;

#endif  /* _ASM_KEXE_BZIMAGE64_H */
