/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_PURGATORY_H
#define _ASM_X86_PURGATORY_H

#ifndef __ASSEMBLY__
#include <linux/purgatory.h>

extern void purgatory(void);
#endif	/* __ASSEMBLY__ */

#endif /* _ASM_PURGATORY_H */
