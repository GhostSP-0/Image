#ifndef _ASM_X86_VMALLOC_H
#define _ASM_X86_VMALLOC_H

#include <asm/pgtable_areas.h>

#endif /* _ASM_X86_VMALLOC_H */
