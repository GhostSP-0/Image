/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _TRACE_ARM64_KVM_H
#define _TRACE_ARM64_KVM_H

#include "trace_arm.h"
#include "trace_handle_exit.h"

#endif	/* _TRACE_ARM64_KVM_H */
